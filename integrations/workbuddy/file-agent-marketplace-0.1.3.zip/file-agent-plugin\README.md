# File Agent WorkBuddy attachment bridge

此插件将用户在本轮 WorkBuddy 消息上传、并明确要求导入、归档、整理、解析或分类的附件交给 File Agent。它不把本机路径、附件 ID 或正文交给模型。

当前仅启用已实测的图片附件块 `image_blob_ref`。PDF、DOCX、XLSX 的 transcript 块格式尚未实测，因此会被安全跳过。

在 WorkBuddy 的「技能 → 套件」中添加市场，然后安装
`file-agent-workbuddy-bridge`。如果当前图形界面只接受市场地址，可以在本机
`integrations/workbuddy` 目录打包 `.codebuddy-plugin` 与 `file-agent-plugin` 两项为
`file-agent-marketplace.zip`，再通过仅绑定 `127.0.0.1` 的本机 HTTP 服务提供该 ZIP。
测试地址示例：`http://127.0.0.1:8765/file-agent-marketplace.zip`。此地址只在
HTTP 服务运行期间有效；不能把未发布到 GitHub 的仓库地址当作已可安装的市场。

如果界面允许添加本地目录，市场根是
`E:\PycharmProject\file-agent\integrations\workbuddy`，不是 `file-agent-plugin`
子目录或 `file-agent-connector` 目录。

安装后，在插件设置填写：

- `python_executable`：例如 `D:\anaconda\envs\myenv\python.exe`。
- `workbuddy_home`：通常为 `C:\Users\zhouhexin\.workbuddy`。
- `bridge_state_dir`：例如 `C:\Users\zhouhexin\.workbuddy\file-agent-bridge-state`。

然后在 `C:\Users\zhouhexin\.workbuddy\mcp.json` 的 `file-agent` 环境变量中添加：

```json
"FILE_AGENT_WORKBUDDY_ATTACHMENT_ROOTS": "[\"C:\\\\Users\\\\zhouhexin\\\\.workbuddy\\\\blobs\"]",
"FILE_AGENT_WORKBUDDY_BRIDGE_STATE_DIR": "C:\\\\Users\\\\zhouhexin\\\\.workbuddy\\\\file-agent-bridge-state"
```

`bridge_state_dir` 与 `FILE_AGENT_WORKBUDDY_BRIDGE_STATE_DIR` 必须完全一致，且不能指向附件缓存目录或项目源代码目录。重启 WorkBuddy 后，上传图片并输入“把这个附件归档并分类”。只有生成本轮可信提交单时，AI 才能调用 `workbuddy_submission_ingest`；随后用 `batch_get`、`job_get` 返回处理结果。只查看或讨论附件时不会导入。

本机 0.1.3 兼容 WorkBuddy 5.5.3 的 Hook 时序：Hook 不再前置扫描尚未包含本轮消息的 transcript，而是立即生成绑定当前会话、固定 transcript 和任务文字的短时待解析引用；AI 调用 `workbuddy_submission_ingest` 时，MCP 再从该固定 transcript 中唯一匹配本轮消息。这个过程不延时轮询、不扫描 WorkBuddy 目录，也不会把路径交给模型。MCP 仍会校验消息时间窗、会话 ID、任务文字、稳定消息 ID 以及附件缓存授权根；缺失或匹配不唯一时直接拒绝。

标准 WorkBuddy 布局下，MCP 会从 `FILE_AGENT_WORKBUDDY_ATTACHMENT_ROOTS` 中以 `blobs` 结尾的授权根推导同级 `projects` transcript 根，不需要新增配置。非标准布局必须另行设置 `FILE_AGENT_WORKBUDDY_TRANSCRIPT_ROOTS` 为路径字符串 JSON 数组。

插件会在 `bridge_state_dir/capture-diagnostics.jsonl` 追加有限状态码（文件不超过 128 KiB），不记录任务文字、文件名、附件 ID、缓存路径或密钥。0.1.3 每次有效发送只应新增一行：`PENDING_MANIFEST_CREATED` 表示已创建待解析引用；`PENDING_INPUT_REJECTED` 或 `MANIFEST_WRITE_FAILED` 表示引用创建失败。旧版遗留的 `SESSION_MESSAGE_MISSING`、`PROMPT_MISMATCH` 或 `MATCHED` 可以忽略。失败时不得复制附件到工作区再调用 `file_batch_ingest` 冒充附件桥接成功。0.1.3 仍需 WorkBuddy 图形客户端的真实上传验收，不能仅以自动化测试通过宣称端到端成功。

提交单默认 10 分钟失效；可用 `FILE_AGENT_WORKBUDDY_SUBMISSION_TTL_SECONDS`（60–3600）调整。
