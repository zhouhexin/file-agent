# File Agent WorkBuddy attachment bridge

当前试点版本：**0.1.6**。在 0.1.5 的附件捕获修复上补齐 WorkBuddy 外部 OCR 编排：图片进入
`WAITING_EXTERNAL_EXTRACTION` 后，不再只查询状态，而是由 Agent 调用 `extraction_claim` 领取固定页，
使用 WorkBuddy 已启用的腾讯文档 `ocr.extract` 识别，再通过 `extraction_submit` 回填，最后继续查重、
归档和分类。File Agent 后端不会因此启用内部 OCR。

0.1.5 已修复 Windows Hook 把宿主 UTF-8 管道按 GBK 解码导致的中文乱码；
捕获与调用校验 Hook 固定读取 UTF-8，输出使用 ASCII JSON 转义。无效 UTF-8、截断 JSON 或孤立代理项
会拒绝创建提交单。消息记录可早于提交单最多 30 秒（兼容实测约 6 秒的宿主附件准备耗时），仍须唯一匹配
固定会话、任务文字和 `image_blob_ref`。未来时钟容差仍为 5 秒，提交单有效期仍为 10 分钟。

升级包：`file-agent-marketplace-0.1.6.zip`。升级套件后完全退出并重开 WorkBuddy，同时加载本项目最新 MCP
代码；`mcp.json` 环境变量、File Agent API 和 worker 本次不需要调整。只升级套件而未加载最新 MCP 时，
模型仍可能只查状态而不执行 OCR。旧版乱码提交单不能修复后重用，必须重新上传并发送任务。

验收时用同一张图片分别测试拖拽和左下角添加，两轮使用不同测试编号，均须收到真实工具批次回执。
如果某种选择方式仅生成 `input_text` 中的本地路径、没有 `image_blob_ref`，仍不支持该轮附件导入；
不能仅凭“从哪个按钮选择”判断是否成功上传。`PENDING_MANIFEST_CREATED` 只证明捕获成功，不证明已完成归档。
新增 `PENDING_INPUT_ENCODING_INVALID` 诊断码表示宿主任务文字损坏。自动化结果以本次发布时测试输出为准；
两种 GUI 上传方式仍需升级后实测，不能把自动化通过当作 GUI 端到端完成。

此插件将用户在本轮 WorkBuddy 消息上传、并明确要求导入、归档、整理、解析或分类的附件交给 File Agent。它不把本机路径、附件 ID 或正文交给模型。

当前仅启用已实测的图片附件块 `image_blob_ref`。PDF、DOCX、XLSX 的 transcript 块格式尚未实测，因此会被安全跳过。

在 WorkBuddy 的「技能 → 套件」中添加市场，然后安装
`file-agent-workbuddy-bridge`。如果当前图形界面只接受市场地址，可以在本机
`integrations/workbuddy` 目录打包 `.codebuddy-plugin` 与 `file-agent-plugin` 两项为
`file-agent-marketplace.zip`，再通过仅绑定 `127.0.0.1` 的本机 HTTP 服务提供该 ZIP。
测试地址示例：`http://127.0.0.1:8765/file-agent-marketplace.zip`。此地址只在
HTTP 服务运行期间有效；不能把未发布到 GitHub 的仓库地址当作已可安装的市场。

如果界面允许添加本地目录，市场根是
`E:\PycharmProject\file-agent\integrations\workbuddy`，不是 `file-agent-plugin`
子目录或 `file-agent-connector` 目录。

安装后，在插件设置填写：

- `python_executable`：例如 `D:\anaconda\envs\myenv\python.exe`。
- `workbuddy_home`：通常为 `C:\Users\zhouhexin\.workbuddy`。
- `bridge_state_dir`：例如 `C:\Users\zhouhexin\.workbuddy\file-agent-bridge-state`。

然后在 `C:\Users\zhouhexin\.workbuddy\mcp.json` 的 `file-agent` 环境变量中添加：

```json
"FILE_AGENT_WORKBUDDY_ATTACHMENT_ROOTS": "[\"C:\\\\Users\\\\zhouhexin\\\\.workbuddy\\\\blobs\"]",
"FILE_AGENT_WORKBUDDY_BRIDGE_STATE_DIR": "C:\\\\Users\\\\zhouhexin\\\\.workbuddy\\\\file-agent-bridge-state"
```

`bridge_state_dir` 与 `FILE_AGENT_WORKBUDDY_BRIDGE_STATE_DIR` 必须完全一致，且不能指向附件缓存目录或项目源代码目录。重启 WorkBuddy 后，上传图片并输入“把这个附件归档并分类”。只有生成本轮可信提交单时，AI 才能调用 `workbuddy_submission_ingest`。若图片等待外部提取，插件 Skill 会继续调用 `extraction_claim`、腾讯文档 `ocr.extract` 和 `extraction_submit`，不能仅重复 `batch_get`/`job_get`。只查看或讨论附件时不会导入。

WorkBuddy 5.5.3 本机已安装并启用的腾讯文档个人版工具当前声明：`ocr.extract` 返回按顺序的
`texts: string[]`，打开位置参数后还返回 `text_detections`；不承诺置信度、Provider 版本或请求 ID，
这些缺失字段回填 `null`。`ocr.toword` 和 `ocr.toexcel` 只返回 `file_id`、`file_url`，不能代替逐页正文回填。
通用 `Read` 以及图片美化套件没有供此链路依赖的结构化 OCR 输出契约。腾讯文档 OCR 的宿主票据仍须在
真实 WorkBuddy 会话内验收；“已安装并启用”不等于已经完成一次有效 OCR 调用。

本机 0.1.4 兼容 WorkBuddy 5.5.3 的 Hook 时序：Hook 不再前置扫描尚未包含本轮消息的 transcript，而是立即生成绑定当前会话、固定 transcript 和任务文字的短时待解析引用；AI 调用 `workbuddy_submission_ingest` 时，MCP 再从该固定 transcript 中唯一匹配本轮消息。0.1.4 同时兼容宿主 JSON 把 emoji 等字符表示为 UTF-16 代理对的情况，写入提交单前会还原为合法 Unicode，不会因 UTF-8 编码异常丢失本轮引用。这个过程不延时轮询、不扫描 WorkBuddy 目录，也不会把路径交给模型。MCP 仍会校验消息时间窗、会话 ID、任务文字、稳定消息 ID 以及附件缓存授权根；缺失或匹配不唯一时直接拒绝。

标准 WorkBuddy 布局下，MCP 会从 `FILE_AGENT_WORKBUDDY_ATTACHMENT_ROOTS` 中以 `blobs` 结尾的授权根推导同级 `projects` transcript 根，不需要新增配置。非标准布局必须另行设置 `FILE_AGENT_WORKBUDDY_TRANSCRIPT_ROOTS` 为路径字符串 JSON 数组。

插件会在 `bridge_state_dir/capture-diagnostics.jsonl` 追加有限状态码（文件不超过 128 KiB），不记录任务文字、文件名、附件 ID、缓存路径或密钥。0.1.4 每次有效发送只应新增一行：`PENDING_MANIFEST_CREATED` 表示已创建待解析引用；`PENDING_INPUT_REJECTED` 或 `MANIFEST_WRITE_FAILED` 表示引用创建失败。旧版遗留的 `SESSION_MESSAGE_MISSING`、`PROMPT_MISMATCH` 或 `MATCHED` 可以忽略。失败时不得复制附件到工作区再调用 `file_batch_ingest` 冒充附件桥接成功。0.1.4 仍需 WorkBuddy 图形客户端的真实上传验收，不能仅以自动化测试通过宣称端到端成功。

提交单默认 10 分钟失效；可用 `FILE_AGENT_WORKBUDDY_SUBMISSION_TTL_SECONDS`（60–3600）调整。
