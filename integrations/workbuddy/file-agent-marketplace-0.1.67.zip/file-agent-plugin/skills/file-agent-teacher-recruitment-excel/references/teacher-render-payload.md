# 教师引进列内格式载荷示例

这里的 `source_unit_id`、`quote`、`start/end` 都必须来自本轮正式 `structured_dataset_source(mode="FULL")` 的真实返回值。示例文字和 UUID 仅说明结构，不能复制为某位教师的数据。`fragment_index` 从本格 `fragments[0]` 起算，`parts[].text` 必须是所指原文 `quote` 中逐字存在的子串。

## I 列学历

假设正式来源有两个独立原文片段：“博士毕业 2026.09 西安理工大学 计算机科学与技术”和“本科毕业 2017.07 西南民族大学 网络工程”，但硕士栏没有记录。本格提交两条带来源位置的 `fragments`，不把“硕博连读”写进 `raw_text`：

```json
{
  "fragments": [
    {"source_unit_id": "<正式UUID-1>", "quote": "博士毕业 2026.09 西安理工大学 计算机科学与技术"},
    {"source_unit_id": "<正式UUID-2>", "quote": "本科毕业 2017.07 西南民族大学 网络工程"}
  ],
  "teacher_render": {
    "kind": "EDUCATION",
    "items": [
      {"stage": "博士", "parts": [
        {"fragment_index": 0, "role": "GRADUATION", "text": "2026.09"},
        {"fragment_index": 0, "role": "SCHOOL", "text": "西安理工大学"},
        {"fragment_index": 0, "role": "MAJOR", "text": "计算机科学与技术"}
      ]},
      {"stage": "本科", "parts": [
        {"fragment_index": 1, "role": "GRADUATION", "text": "2017.07"},
        {"fragment_index": 1, "role": "SCHOOL", "text": "西南民族大学"},
        {"fragment_index": 1, "role": "MAJOR", "text": "网络工程"}
      ]}
    ]
  }
}
```

服务端生成的 Excel I 格：

```text
博士：2026.09
西安理工大学
计算机科学与技术

硕士：硕博连读

本科：2017.07
西南民族大学
网络工程
```

若片段在来源单元中重复，必须附上正式文本中的真实 `start/end` 字符范围。来源明确显示硕士阶段时必须提交该阶段的真实片段，不能触发默认句。

## J/K/L 与 M/N/O 的同号规则

J 的 `teacher_render` 是 `kind="PAPER"`，每篇一条 `items`，`ordinal` 从 1 连续递增；每个条目用 `role="TEXT"` 指向论文题目。K/L 的每条只保留有证据的论文，沿用 J 中的原 `ordinal`。K 的刊号和刊名用 `ISSN`、`JOURNAL_NAME`，作者角色等用 `TEXT`；L 的原文收录/IF 用 `TEXT`，明确的 SCI/SSCI/A&HCI 分区用 `ZONE`。L 根据期刊名称或 ISSN 触发学校目录判级时，`teacher_render.catalog_version_id` 必须等于本轮 `reference_catalog_get` 返回的版本；服务端会再次精确查询并校验。会议不传期刊目录字段。每篇最终展示为 `1.内容`，篇间一个换行。

M/N/O 的 `kind="PROJECT"`，分别用本列真实原文 `TEXT` 片段组成条目；同一项目使用同一个 `ordinal`，项目间空一行。某列缺少某项目时不造 `n.` 占位，后续项目不重新编号。P 的 `kind="ACHIEVEMENT"`，条目间一个换行。I–P 的实际物理列与本次目标真实表头不一致时不要使用这些格式标识。

## 发布前核对

`excel_writeback_apply.rows` 中有值的格必须是上述规则的**最终展示字符串**，A 和所有空格省略。下载预览需逐格核对 J/K/L 的同号关系、M/N/O 的同号关系、I 的阶段空行和新行的自动换行/行高；`excel_writeback_publish` 会再次核对格式值、来源引文、目录版本和工作簿差异。失败时按错误码停止，不能报“已保存”。
