---
name: file-agent-a-i-scoped-excel
description: 当用户明确要求只把职称评审 PDF 的身份与任职信息填入业绩汇总 Excel 物理 A–I 列时，使用定向 PDF OCR 和受控 Excel 写入；不适用于全文提取或 J–AA 业绩填写。
---

# A–I 定向识别并填表

本 Skill 只处理用户明确限定物理 A–I 列的任务。A 列使用目标 Excel 的序号规则；PDF OCR 必须覆盖 B–I 八列，不能为 J–AA 读取业务页或生成候选。读取 [B–I 来源路由](references/a-i-source-map.md) 时，把页号视为已核对版式的候选范围，不把参考样本的值带入本轮结果。

## 先检查能力与目标

1. 在接收/导入本轮来源 PDF 前检查实时 MCP 工具与 schema。必须有专用 `SCOPED_EXCEL_FILL` 入口、`workbuddy-scoped-pdf-v1` 定向提取契约、`scoped_pdf_source_prepare/claim/submit` 或服务端声明的等价受控工具，以及明确支持 `write_scope` 和 `required_pdf_columns` 的 Excel 发布工具。若缺少任何一项，报告定向能力未部署并停止；不能改用 `WORKBUDDY_DOCUMENT`、`document_extraction_submit`、`structured_dataset_*` 的无范围旧调用或整篇 OCR 冒充。
2. 从本轮可信附件提交引用或服务端返回的稳定对象 ID 固定来源和目标。新上传 Excel 优先作为新目标；没有新 Excel 时，按用户给出的完整文件名唯一定位现有目标。重复上传、同名、多个工作表、目标版本冲突遵守附件桥接和目标表的现有选择/冲突流程，不能自行选一个。
3. OCR 前由真实电子表格能力读取目标 sheet 的完整 A–AA 表头、合并区域、真实 `TABLE_CELL` 网格、预置数据行和现有值；服务端须核对布局。只读全表结构是保护模板，不能据此要求处理 J–AA 的 PDF 内容。旧 `.xls` 只交给服务端现有受控格式提升；WorkBuddy 不自行重建或另存目标。
4. 取得服务端冻结的 `scope_digest`、目标稳定 ID/当前版本与哈希、`write_columns=A..I`、`required_pdf_columns=B..I`、PDF 源版本与哈希、页/区域白名单。工具只返回整份 PDF 或不能证明页/区域范围时停止，不启动 OCR。

## 只 OCR B–I 的来源区域

- 对已核对的参考版式，候选为 PDF 物理第 1 页封面身份栏及第 3 页“基本情况”中 B–I 所需区域。页号和裁剪框必须来自本轮服务端冻结的范围，不从文件名、旧会话或本 Skill 直接生成执行参数。版式不符或栏目缺失时返回定位问题；需要新增页面由用户指定后创建新的范围快照，不顺序扫描其他页面。
- `scoped_pdf_source_claim` 必须只交付冻结页/区域的图像资源，附来源版本/哈希、原始页号、裁剪坐标和区域哈希。只把这些区域图像送入 WorkBuddy 已安装、已授权的真实 OCR Provider；`provider_name` 用实际工具名称。不得把整份 PDF 或未授权页图交给 OCR、文档读取模型或其他外部能力。没有可用区域 OCR Provider 时停止。
- 把 OCR 原文、真实页号、区域位置和可用的字符/图像位置绑定到 B–I 各列。同一原文可支撑多列，但每列都要有独立字段映射和可核对引文。OCR 负责识别具体值；不要从文件名、Excel 旧值、示例材料或模型视觉补值。某列读不清时仅在同一授权区域按工具预算重试；仍不清楚则标记该列 `UNRESOLVED`，不扩大到全文。
- 只提交白名单内实际 OCR 的区域和 B–I 八列结果。`SCOPE_COMPLETE` 仅在八列都有真实原文与页/区域证据时成立；任何缺列、页/区域越界或 `SCOPE_INCOMPLETE` 均停止 Excel 发布。未读的其余 PDF 页面保持 `NOT_READ`，不得伪装为 `BLANK` 或完整文档提取。

## 发布 Excel

使用冻结的 `write_scope=A..I` 和 `required_pdf_columns=B..I` 构造候选：A 保留/确定目标序号并标记 `TARGET_DERIVED`；B–I 各附本轮定向提取运行中的正式证据；J–AA 全部标记 `OUT_OF_SCOPE`。不运行这些列的审批、资格、对勾或缺失字段判断。

调用受控预览与发布工具，让服务端重新核对八列证据、目标版本 CAS、单元格差异和 J–AA 零改动。默认 `DIRECT_SAVE`；用户本轮明确要求先看、复核或确认后保存时采用 `REVIEW_REQUIRED`，展示本轮八列实际值和证据并等待用户确认同一指纹。不能用本地 Office、Shell、私有 API 或旧导出器绕过发布校验。

只有工具返回 `SCOPE_COMPLETE`、Excel `excel_published=true`、稳定目标/版本 ID 和下载资源时才报告完成。回执列出 A–I 的写入结果、B–I 来源页/区域、J–AA 未处理、实际 OCR 页/区域数、最终文件名和版本。失败时说明缺列或阻塞阶段，不称整份 PDF 已读，也不称 Excel 已保存。恢复只复用同一 `scope_digest`、来源版本和幂等键，避免重复 OCR 或追加同一人员行。
