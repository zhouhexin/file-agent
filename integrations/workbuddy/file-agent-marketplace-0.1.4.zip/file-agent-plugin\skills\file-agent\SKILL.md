---
name: file-agent-attachment-bridge
description: 当本轮上下文含 FILE_AGENT_HOST_SUBMISSION，且用户明确要求导入、归档、整理、解析或分类所附文件时，使用 File Agent 的可信附件提交单工具。
---

# File Agent 附件桥接

仅在当前轮出现 `FILE_AGENT_HOST_SUBMISSION ref=...` 时，且用户明确要求将附件导入、归档、整理、解析、OCR 或分类，调用。`count=pending` 是 WorkBuddy 5.5.3/插件 0.1.4 的正常延迟解析状态，不是失败：

`workbuddy_submission_ingest(submission_ref=<ref>)`

不要调用旧的 `workbuddy_attachment_ingest`，不要索取、猜测或传入 `local_path`、`attachment_id`、文件名和 `user_request`。如果用户只是查看附件、讨论附件内容，或没有表达保存到 File Agent 的意图，不调用导入工具。

如果用户要求归档本轮上传的附件，但当前轮没有 `FILE_AGENT_HOST_SUBMISSION ref=...`，应说明附件桥接尚未提供可信提交单并停止本次导入。不得用 Bash、`cp`、`Copy-Item` 将附件复制到授权目录，也不得用 `file_batch_ingest` 冒充本轮附件导入。用户另外明确指定已授权本地目录的批量导入不受这条附件边界影响。

工具返回后，用 `batch_get` 和 `job_get` 查询处理结果；如出现重复文件，使用返回的复核信息继续处理，不要自行判断或忽略。
