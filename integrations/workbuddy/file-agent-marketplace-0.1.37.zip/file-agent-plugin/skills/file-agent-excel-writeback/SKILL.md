---
name: file-agent-excel-writeback
description: 用户明确要求由 WorkBuddy 写入完整 Excel 并回传 File Agent 保存时使用；新上传模板或按文件名追加均可，旧 structured_dataset_* 路线保持可用。
---

# WorkBuddy 写完整 Excel，服务器验证发布

此 Skill 使用独立 `excel_writeback_*` MCP 工具。不要把它和旧
`structured_dataset_preview/confirm/commit` 混用；同一任务只能选一个写入者。
WorkBuddy 负责读取 PDF、Word、图片及目标 Excel 字段，决定最终各格展示值；
File Agent 只核对正式来源、审批证据、当前目标版本与文件差异，然后发布同名工作副本。
工具缺失或功能开关未启用时说明能力未就绪；不得用 Shell、SQL、临时重建 Excel 或旧工具假装完成新链路。

## 目标与来源

1. 本轮有新上传 Excel，优先以该文件为目标；提供已归档 `uploaded_document_id`，必要时提供版本、
   工作表和布局。多工作表、多同名文件或表头不清楚时先请用户选定。本轮没有新 Excel 时，
   按用户给出的完整文件名 checkout 已有目标；找不到或重名必须让用户确认，不能猜测。
2. 调用 `excel_writeback_checkout`，保留返回的 `task_id`、稳定目标 ID、当前版本、SHA-256、
   `sheet_name`、完整 `labels` 和 `layout`。`.xls` 必须先由服务器受控异步提升为 `.xlsx`；
   等任务实际完成后重试，不让 WorkBuddy 自行转换或重建原模板。
3. 只从 checkout 的当前 Excel 读字段和已有内容，不能用上次本地缓存。读取来源材料沿用主 Skill 的
   WorkBuddy 文档提取任务和真实可用 Provider，不固定 OCR 提供商、不回退到程序内部 OCR。
   需要盖章范围判断时同时遵守 `file-agent-sealed-item-extraction` 的审批、来源事实、身份列、
   整列资格和末尾单次 `√` 规则；无章事实允许写入的范围以该专用 Skill 为准。
4. 用与旧任务一致的 `TaskPayload`：`manifest.target` 只设 `dataset_id`、当前
   `document_version_id`、实际 `filename/sheet_name/layout/labels`；每条来源固定正式 ID 和 SHA-256；
   每个记录逐列覆盖全部字段，有内容给原文引用及需要的审批/条件证据，无内容给 `blank_reason`。
   多来源记录按 `source_index` 升序，每个人一行。不能编造引文、印章、勾选或缺失值。

## 本机写入与预览

1. WorkBuddy 根据已核实的每列结果形成 `rows`，顺序和 `payload.records`、`labels` 完全相同。
   `rows` 是 Excel 中实际展示值，符合整列条件才在整个数据格文字末尾加一次 ` √`；
   不在标题或每个小项后加勾。预置序号格可传 `null` 保留模板序号。
2. 调用 `excel_writeback_apply(task_id,payload,rows)`。它从冻结基线重新写候选文件，
   只修改目标工作表新数据格，原工作簿其他 ZIP 部件原字节保留，同时登记完整文件和候选共同摘要。
   不要使用普通编辑器另存、`openpyxl.save` 或自行复制整张表代替；这些方式可能重写公式、样式、
   图表和其他工作表，服务器将拒绝。如果专用本地写入工具不能处理模板，停止并说明原因。
3. `REVIEW_REQUIRED`：必须向用户展示 `preview_result` 中所有逐列具体值、证据、审批状态、
   留空/排除原因及最终 Excel 文件名，询问确认并结束本轮。用户修正后重新 checkout 新任务和新指纹。
   用户明确确认同一预览后才调用 `excel_writeback_confirm(task_id,result_digest)`。
4. `DIRECT_SAVE`：专用盖章 Skill 且用户未要求先复核，或用户明确授权无需复核时使用；
   仍必须完成真实读取、逐列证据和 apply 预览登记，但无需调用 confirm，直接 publish。
   其他情况默认 `REVIEW_REQUIRED`。不得因为耗时、失败或缺证据擅自切换为直写。

## 发布与回执

调用 `excel_writeback_publish(task_id,result_digest,payload)`。工具只回传固定任务目录内的完整
`.xlsx`，服务端再次逐字校验证据、条件和 `√`、旧版本 CAS、表头、原有行、样式、公式、
非目标工作表和 OOXML 部件。若模板部件被重写或目标版本已变化，停止并重新 checkout，
不能覆盖当前文件。失败时不得宣称“已保存”。

仅当返回 `status=COMPLETED`、`excel_published=true`、`task_record_count>0`，
且含 `dataset_id/working_copy_id/document_id/document_version_id/version_number/filename/export_id`
及下载 ResourceLink 时报告成功。向用户报实际同名文件、版本号、本轮增加的记录数、填入和留空的列。
服务器只维护一个可见的同名当前工作副本；旧版本由 DocumentVersion 管理，后续仍按文件名继续追加。
本地可编辑缓存或单纯 `preview` 成功不代表服务器文件已生成。
