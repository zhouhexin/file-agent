#!/usr/bin/env python3
"""把本轮已验证的 WorkBuddy 附件写成可信提交单。

仅支持已在本机 transcript 中验证过的 ``image_blob_ref``。脚本不读取附件正文，
不把文件路径或原始文件名注入模型上下文；未知附件块一律不导入。
"""

from __future__ import annotations

import json
import os
import secrets
import stat
import sys
import time
from pathlib import Path
from typing import Any


_VERIFIED_ATTACHMENT_TYPES = frozenset({"image_blob_ref"})


def _capture_unavailable_result() -> dict[str, Any]:
    """明确阻断附件任务的目录回退，同时不影响用户单独授权的目录导入。"""

    return {
        "continue": True,
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": (
                "FILE_AGENT_ATTACHMENT_BRIDGE_UNAVAILABLE。当前轮没有生成可信附件提交单。"
                "如果用户要求导入、归档、解析、OCR、整理或分类本轮附件，必须说明当前附件无法安全提交并停止；"
                "不得用 Bash、cp、Copy-Item 或其他文件工具把附件复制到工作区或授权目录，"
                "也不得调用 file_batch_ingest 冒充附件桥接成功。"
                "只有用户另外明确指定已授权目录进行批量导入时，才允许正常使用 file_batch_ingest。"
            ),
        },
    }


def _workbuddy_home() -> Path:
    """读取插件配置的 WorkBuddy 数据目录。"""

    configured = os.getenv("CODEBUDDY_PLUGIN_OPTION_WORKBUDDY_HOME") or os.getenv(
        "FILE_AGENT_WORKBUDDY_HOME"
    ) or str(Path.home() / ".workbuddy")
    return Path(configured).expanduser().resolve()


def _state_dir() -> Path | None:
    """取得插件私有持久化目录；缺失时保持只读且不创建提交单。"""

    raw = (
        os.getenv("CODEBUDDY_PLUGIN_OPTION_BRIDGE_STATE_DIR")
        or os.getenv("CODEBUDDY_PLUGIN_DATA", "")
    ).strip()
    if not raw:
        return None
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute() or candidate.is_symlink():
        return None
    candidate.mkdir(parents=True, exist_ok=True)
    if candidate.is_symlink() or not candidate.is_dir():
        return None
    return candidate.resolve()


def _safe_transcript_path(*, raw_path: object, workbuddy_home: Path) -> Path | None:
    """只接受 WorkBuddy projects 根内的普通 JSONL transcript。"""

    if not isinstance(raw_path, str) or not raw_path.strip():
        return None
    candidate = Path(raw_path).expanduser()
    if not candidate.is_absolute() or candidate.is_symlink():
        return None
    try:
        resolved = candidate.resolve(strict=True)
        projects_root = (workbuddy_home / "projects").resolve(strict=True)
    except OSError:
        return None
    if resolved.suffix.lower() != ".jsonl" or projects_root not in resolved.parents:
        return None
    return resolved if resolved.is_file() else None


def _message_matches_prompt(message: dict[str, Any], prompt: object) -> bool:
    """用 Hook 本轮 prompt 交叉校验 transcript 用户消息，避免复用历史附件。"""

    if not isinstance(prompt, str) or not prompt.strip():
        return False
    texts = [
        str(part.get("text") or "")
        for part in message.get("content") or []
        if isinstance(part, dict) and part.get("type") == "input_text"
    ]
    return " ".join(prompt.split()) in " ".join(" ".join(texts).split())


def _safe_blob_path(*, raw_path: object, workbuddy_home: Path) -> Path | None:
    """限制 blob 必须位于 WorkBuddy blobs 根内且为非链接普通文件。"""

    if not isinstance(raw_path, str) or not raw_path:
        return None
    candidate = Path(raw_path).expanduser()
    if not candidate.is_absolute() or candidate.is_symlink():
        return None
    try:
        resolved = candidate.resolve(strict=True)
        blobs_root = (workbuddy_home / "blobs").resolve(strict=True)
        mode = resolved.stat().st_mode
    except OSError:
        return None
    if blobs_root not in resolved.parents or not stat.S_ISREG(mode):
        return None
    return resolved


def _current_submission(
    payload: dict[str, Any],
) -> tuple[tuple[dict[str, Any], Path] | None, str, int, int, str]:
    """只匹配当前会话与任务文字，并返回不含用户内容的失败状态码。"""

    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        return None, "SESSION_ID_MISSING", 0, 0, "unknown"
    transcript = _safe_transcript_path(
        raw_path=payload.get("transcript_path"), workbuddy_home=_workbuddy_home()
    )
    if transcript is None:
        return None, "TRANSCRIPT_REJECTED", 0, 0, "unknown"
    if not isinstance(payload.get("prompt"), str) or not payload["prompt"].strip():
        return None, "PROMPT_MISSING", 0, 0, "unknown"
    latest_match: dict[str, Any] | None = None
    latest_user: dict[str, Any] | None = None
    session_user_count = 0
    try:
        with transcript.open("r", encoding="utf-8") as source:
            for raw_line in source:
                try:
                    item = json.loads(raw_line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(item, dict) or item.get("role") != "user":
                    continue
                if (item.get("sessionId") or item.get("session_id")) != session_id:
                    continue
                session_user_count += 1
                latest_user = item
                if _message_matches_prompt(item, payload.get("prompt")):
                    latest_match = item
    except OSError:
        return None, "TRANSCRIPT_READ_FAILED", 0, 0, "unknown"
    latest_image_count = sum(
        isinstance(part, dict) and part.get("type") == "image_blob_ref"
        for part in (latest_user or {}).get("content") or []
    )
    raw_timestamp = (latest_user or {}).get("timestamp")
    if isinstance(raw_timestamp, (int, float)):
        timestamp_seconds = raw_timestamp / 1000 if raw_timestamp > 10**11 else raw_timestamp
        age = time.time() - timestamp_seconds
        age_bucket = "recent" if -5 <= age <= 60 else "old"
    else:
        age_bucket = "unknown"
    if latest_match is None:
        status = "PROMPT_MISMATCH" if session_user_count else "SESSION_MESSAGE_MISSING"
        return None, status, session_user_count, latest_image_count, age_bucket
    return (latest_match, _workbuddy_home()), "MATCHED", session_user_count, latest_image_count, age_bucket


def _record_capture_status(
    state_dir: Path,
    *,
    status: str,
    attachment_count: int = 0,
    session_user_count: int = 0,
    latest_image_count: int = 0,
    latest_user_age: str = "unknown",
) -> None:
    """仅保存有限的状态码和数量，避免诊断日志暴露正文、文件名或路径。"""

    target = state_dir / "capture-diagnostics.jsonl"
    try:
        # 诊断文件有上限，不能让大量普通会话无限占用插件私有目录。
        if target.is_symlink() or (target.exists() and (not target.is_file() or target.stat().st_size >= 131072)):
            return
        record = {
            "time": int(time.time()),
            "status": status,
            "attachment_count": attachment_count,
            "session_user_count": min(session_user_count, 1000),
            "latest_image_count": min(latest_image_count, 1000),
            "latest_user_age": latest_user_age,
        }
        with target.open("a", encoding="utf-8") as output:
            output.write(json.dumps(record, separators=(",", ":")) + "\n")
    except OSError:
        # 诊断记录失败不能改变附件提交的授权结论。
        return


def capture_submission(payload: dict[str, Any]) -> dict[str, Any]:
    """生成不可猜测的提交单引用，并只向 Agent 注入引用和固定路由指令。"""

    if payload.get("hook_event_name") != "UserPromptSubmit":
        return {"continue": True}
    current, capture_status, user_count, image_count, user_age = _current_submission(payload)
    state_dir = _state_dir()
    if state_dir is None:
        return _capture_unavailable_result()
    if current is None:
        _record_capture_status(
            state_dir,
            status=capture_status,
            session_user_count=user_count,
            latest_image_count=image_count,
            latest_user_age=user_age,
        )
        return _capture_unavailable_result()
    message, workbuddy_home = current
    attachments: list[dict[str, str]] = []
    for part in message.get("content") or []:
        if not isinstance(part, dict) or part.get("type") not in _VERIFIED_ATTACHMENT_TYPES:
            continue
        attachment_id = part.get("blob_id")
        filename = part.get("original_filename")
        path = _safe_blob_path(raw_path=part.get("blob_path"), workbuddy_home=workbuddy_home)
        if not isinstance(attachment_id, str) or not attachment_id or not isinstance(filename, str) or path is None:
            continue
        if filename in {"", ".", ".."} or len(filename) > 255 or any(x in filename for x in ("/", "\\", "\x00")):
            continue
        attachments.append({"attachment_id": attachment_id, "filename": filename, "local_path": str(path)})
    if not attachments:
        _record_capture_status(state_dir, status="NO_VERIFIED_ATTACHMENTS")
        return _capture_unavailable_result()
    submission_ref = f"wbsub_v1_{secrets.token_hex(16)}"
    submission_id = str(message.get("uuid") or message.get("id") or submission_ref)
    manifest = {
        "version": 1,
        "submission_ref": submission_ref,
        "submission_id": submission_id,
        "session_id": payload["session_id"],
        "created_at": time.time(),
        "prompt": str(payload["prompt"]),
        "attachments": attachments,
    }
    submissions_dir = state_dir / "submissions"
    submissions_dir.mkdir(parents=True, exist_ok=True)
    target = submissions_dir / f"{submission_ref}.json"
    temporary = submissions_dir / f".{submission_ref}.{secrets.token_hex(8)}.tmp"
    try:
        temporary.write_text(json.dumps(manifest, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        os.replace(temporary, target)
    except OSError:
        temporary.unlink(missing_ok=True)
        _record_capture_status(state_dir, status="MANIFEST_WRITE_FAILED")
        return _capture_unavailable_result()
    _record_capture_status(state_dir, status="MANIFEST_CREATED", attachment_count=len(attachments))
    return {
        "continue": True,
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": (
                "FILE_AGENT_HOST_SUBMISSION "
                f"ref={submission_ref}; count={len(attachments)}。"
                "这是本轮固定附件清单。仅当用户明确要求导入、归档、整理、解析或分类附件时，"
                "调用 workbuddy_submission_ingest，并且只传 submission_ref；不要索取或构造路径、"
                "附件 ID、文件名或 user_request。"
            ),
        },
    }


def main() -> int:
    """读取 Hook stdin 并仅输出符合 WorkBuddy Hook 契约的 JSON。"""

    try:
        payload = json.load(sys.stdin)
    except (json.JSONDecodeError, OSError):
        payload = {}
    result = capture_submission(payload) if isinstance(payload, dict) else {"continue": True}
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
